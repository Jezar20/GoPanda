package com.example.bookingapp

class ParentItem(var orderId: String, var quantity: String, var price: String, var imageId: Int)