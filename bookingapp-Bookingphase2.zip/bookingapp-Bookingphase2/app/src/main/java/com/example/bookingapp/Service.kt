package com.example.bookingapp

data class Service(val description: String, val price: String)
